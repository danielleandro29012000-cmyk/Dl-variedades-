# 🛍️ DL Variedades

Loja online criada em React com Tailwind CSS, pronta para deploy gratuito na Vercel.

## 🚀 Como publicar

1. Crie uma conta no [GitHub](https://github.com) e no [Vercel](https://vercel.com).
2. Faça upload dos arquivos deste projeto em um novo repositório.
3. Na Vercel, clique em **Import Project** e selecione o repositório.
4. Pronto! Sua loja estará online (exemplo: https://dl-variedades.vercel.app).

---

### 🧩 Tecnologias
- React 18
- Vite
- Tailwind CSS

Desenvolvido para DL Variedades 🇧🇷
