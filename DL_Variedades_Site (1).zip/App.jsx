import React from 'react';
import DLVariedades from './DLVariedades';

function App() {
  return <DLVariedades />;
}

export default App;
